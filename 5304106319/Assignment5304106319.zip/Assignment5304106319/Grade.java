package AssignmentJavaDeveloper;

public class Grade {
	private String grade;

	public Grade(String grade) {
		super();
		this.grade = grade;
	}

	public String getGrade() {
		return grade;
	}	
	
}
