package AssignmentJavaDeveloper;


public class Section {
	private int sec;
	private Grade grade;
	
	
	public Section(int sec) {
		super();
		this.sec = sec;
	}


	public int getSec() {
		return sec;
	}


	//public void setSec(int sec) {
	//	this.sec = sec;
	//}


	public Grade getGrade() {
		return grade;
	}


}
